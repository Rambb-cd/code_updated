/**
 * 
 */
package com.exch.rate.util;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author GC1
 *
 */
public class DateUtil {

	public static List<LocalDate> getDatesinRange(LocalDate startDate, LocalDate endDate) {
		System.out.println("Start Date : " + startDate.format(DateTimeFormatter.ISO_LOCAL_DATE));
		System.out.println("End Date : " + endDate.format(DateTimeFormatter.ISO_LOCAL_DATE));
		long numOfDays = ChronoUnit.DAYS.between(startDate, endDate);
        return Stream.iterate(startDate, date -> date.plusDays(1))
                .limit(numOfDays)
                .collect(Collectors.toList());
	}
	
	public static LocalDate convertToLocalDateViaMilisecond(Date dateToConvert) {
	    return Instant.ofEpochMilli(dateToConvert.getTime())
	      .atZone(ZoneId.systemDefault())
	      .toLocalDate();
	}
	
	public static String convertDateToString(Date dateToConvert) {
		SimpleDateFormat dmyFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date = dmyFormat.format(dateToConvert);	
	    return date;
	}
}
