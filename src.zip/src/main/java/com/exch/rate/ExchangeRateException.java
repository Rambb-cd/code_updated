package com.exch.rate;

public class ExchangeRateException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Used to hols the exception type code
    private String code;
    // Used to hold the exception message text
    private String message;

    /**
     * Default Constructor
     */
    public ExchangeRateException() {

        super();
    }

    /**
     *
     * @param code
     * @param message
     */
    public ExchangeRateException(String code, String message) {

        this.code = code;
        this.message = message;
    }

    /**
     * @param message
     */
    public ExchangeRateException(String message) {

        super(message);
        this.message = message;
    }

    /**
     * @param cause
     */
    public ExchangeRateException(Throwable cause) {

        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public ExchangeRateException(String message, Throwable cause) {

        super(message, cause);
        this.message = message;
    }

    /**
     * @return the errorCode
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the message
     */
    @Override
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
