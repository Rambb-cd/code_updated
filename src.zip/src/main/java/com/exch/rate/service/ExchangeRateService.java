/**
 * 
 */
package com.exch.rate.service;

import java.util.List;

import com.exch.rate.dto.ExchangeRateListDTO;
import com.exch.rate.model.ExchangeRateModel;

/**
 * @author GC1
 *
 */
public interface ExchangeRateService {
	public void loadExchangeRates(ExchangeRateListDTO exchangeRateList);
	public void saveExchangeRates(ExchangeRateListDTO exchangeRateList);
	public List<ExchangeRateModel> getExchangeRates();
	public List<ExchangeRateModel> getExchangeRateDate(ExchangeRateListDTO exchangeRateList); 
}
