/**
 * 
 */
package com.exch.rate.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.exch.rate.controller.ExchangeRateLoadController;
import com.exch.rate.dto.ExchangeRateDTO;
import com.exch.rate.dto.ExchangeRateListDTO;
import com.exch.rate.dto.ExhangeRatesDTO;
import com.exch.rate.model.ExchangeRateModel;
import com.exch.rate.repository.ExchangeRateRepo;
import com.exch.rate.service.ExchangeRateService;
import com.exch.rate.util.DateUtil;

/**
 * To Get the Data from the external api
 *
 */
@Service
public class ExchangeRateServiceImpl implements ExchangeRateService {
	private static final Logger LOGGER = LogManager.getLogger(ExchangeRateServiceImpl.class);
	
	@Autowired
	ExchangeRateRepo exchangeRateRepo;
	@Override
	public void loadExchangeRates(ExchangeRateListDTO exchangeRateListDTO) {
		// TODO Auto-generated method stub
		LOGGER.info("ExchangeRateServiceImpl loadExchangeRates() starts");
		Date fromDate = exchangeRateListDTO.getFromDate();
		Date toDate = exchangeRateListDTO.getToDate();
		if (fromDate == null && toDate == null) {
			ExchangeRateListDTO newExchangeRateListDTO = getExchangeRateData(null);
			exchangeRateListDTO.setExchangeRateList(newExchangeRateListDTO.getExchangeRateList());
		} else {
			if (fromDate != null && toDate != null) {
				LocalDate fromLocalDate = DateUtil.convertToLocalDateViaMilisecond(fromDate);
				LocalDate toLocalDate = DateUtil.convertToLocalDateViaMilisecond(toDate);
				List<LocalDate> dateRangeList = DateUtil.getDatesinRange(fromLocalDate, toLocalDate);
				exchangeRateListDTO.setExchangeRateList(new ArrayList<ExchangeRateDTO>());
				for (LocalDate localDate: dateRangeList) {
					Date exchangeDate = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
					ExchangeRateListDTO newExchangeRateListDTO = getExchangeRateData(DateFormatUtils.format(exchangeDate, "yyyy-MM-dd"));
					exchangeRateListDTO.getExchangeRateList().addAll(newExchangeRateListDTO.getExchangeRateList());
				}
			} else if (fromDate != null) {
				ExchangeRateListDTO newExchangeRateListDTO = getExchangeRateData(DateFormatUtils.format(fromDate, "yyyy-MM-dd"));
				exchangeRateListDTO.setExchangeRateList(newExchangeRateListDTO.getExchangeRateList());
			} else if (toDate != null) {
				ExchangeRateListDTO newExchangeRateListDTO = getExchangeRateData(DateFormatUtils.format(toDate, "yyyy-MM-dd"));
				exchangeRateListDTO.setExchangeRateList(newExchangeRateListDTO.getExchangeRateList());
			}
		}
		LOGGER.info("ExchangeRateServiceImpl loadExchangeRates() ends");
	}
	
	private ExchangeRateListDTO getExchangeRateData(String exchangeDate) {
		ExchangeRateListDTO exchangeRateListDTO = new ExchangeRateListDTO();
		String uri = "https://api.ratesapi.io/api/";
		
		if (exchangeDate != null) {
			uri = uri + exchangeDate;
		} else {
			uri = uri + "latest";
		}
	    
		//System.out.println("--------------------------------------------------------------");
		//System.out.println("Rate API URL : " + uri);
		
	    RestTemplate restTemplate = new RestTemplate();
	    ExhangeRatesDTO exchangeRates = restTemplate.getForObject(uri, ExhangeRatesDTO.class);
	    
	    if (exchangeRates != null) {
	    	ExchangeRateDTO gbpExchangeRateDTO = new ExchangeRateDTO();
	    	gbpExchangeRateDTO.setBaseCurrency(exchangeRates.getBase());
	    	gbpExchangeRateDTO.setTargetCurrency("GBP");
	    	gbpExchangeRateDTO.setExchangeRateAmt(exchangeRates.getRates().getGBP());
	    	
	    	//System.out.println("Base : " + gbpExchangeRateDTO.getBaseCurrency());
	    	//System.out.println("GBP : " + gbpExchangeRateDTO.getExchangeRateAmt());
	    	
	    	ExchangeRateDTO usdExchangeRateDTO = new ExchangeRateDTO();
	    	usdExchangeRateDTO.setBaseCurrency(exchangeRates.getBase());
	    	usdExchangeRateDTO.setTargetCurrency("USD");
	    	usdExchangeRateDTO.setExchangeRateAmt(exchangeRates.getRates().getUSD());
	    	
	    	//System.out.println("USD : " + usdExchangeRateDTO.getExchangeRateAmt());
	    	
	    	ExchangeRateDTO hkdExchangeRateDTO = new ExchangeRateDTO();
	    	hkdExchangeRateDTO.setBaseCurrency(exchangeRates.getBase());
	    	hkdExchangeRateDTO.setTargetCurrency("HKD");
	    	hkdExchangeRateDTO.setExchangeRateAmt(exchangeRates.getRates().getHKD());
	    	
	    	//System.out.println("HKD : " + hkdExchangeRateDTO.getExchangeRateAmt());
	    	
	    	hkdExchangeRateDTO.setExchangeRateAmt(exchangeRates.getRates().getHKD());
	    	try {
	    		gbpExchangeRateDTO.setExchangeRateDt(DateUtils.parseDate(exchangeRates.getDate(), "yyyy-MM-dd"));
	    		usdExchangeRateDTO.setExchangeRateDt(DateUtils.parseDate(exchangeRates.getDate(), "yyyy-MM-dd"));
	    		hkdExchangeRateDTO.setExchangeRateDt(DateUtils.parseDate(exchangeRates.getDate(), "yyyy-MM-dd"));
		    } catch (ParseException prExp) {
				prExp.printStackTrace();
			}
	    	ArrayList<ExchangeRateDTO> exchangeRateList = new ArrayList<ExchangeRateDTO>();
	    	exchangeRateList.add(gbpExchangeRateDTO);
	    	exchangeRateList.add(usdExchangeRateDTO);
	    	exchangeRateList.add(hkdExchangeRateDTO);
	    	exchangeRateListDTO.setExchangeRateList(exchangeRateList);
	    }
	    //System.out.println("--------------------------------------------------------------");
		return exchangeRateListDTO;
	}
	//to Save the Date into DB
	@Transactional
	public void saveExchangeRates(ExchangeRateListDTO exchangeRateList) {
		LOGGER.info("ExchangeRateServiceImpl saveExchangeRates() starts");
		//System.out.println("save--------------------------------------------------------------");
		List<ExchangeRateModel> entities = new ArrayList<>();
		
		
		
		//System.out.println("save--" + exchangeRateList.getExchangeRateList().size());
		//for (ExchangeRateDTO exchangeRateDTO : exchangeRateList.getExchangeRateList()) {
		for (int i = 0; i < exchangeRateList.getExchangeRateList().size(); i++)  {
			//System.out.println("save:::::::::::11111 ");
			ExchangeRateDTO exchangeRateDTO  = new ExchangeRateDTO();
			ExchangeRateModel exchangeRateModel = new ExchangeRateModel();
					
			exchangeRateDTO = exchangeRateList.getExchangeRateList().get(i);
			//System.out.println("save:TTT:::: "+exchangeRateDTO.getBaseCurrency());
			
			exchangeRateModel.setBaseCntry(exchangeRateDTO.getBaseCurrency());	
			//String date = dmyFormat.format(exchangeRateDTO.getExchangeRateDt());	
			//DateUtil.convertDateToString(exchangeRateDTO.getExchangeRateDt());
			exchangeRateModel.setDate_conCntry(DateUtil.convertDateToString(exchangeRateDTO.getExchangeRateDt()));
			exchangeRateModel.setTargetCntry(exchangeRateDTO.getTargetCurrency());
			exchangeRateModel.setValueCntry(exchangeRateDTO.getExchangeRateAmt());
			entities.add(exchangeRateModel);
			
			}
		
		exchangeRateRepo.saveAll(entities);
		//System.out.println("save end--------------------------------------------------------------");
		LOGGER.info("ExchangeRateServiceImpl saveExchangeRates() ends");
	}
	//get the values from the DB
	 public List<ExchangeRateModel> getExchangeRates()
	    {
	        List<ExchangeRateModel> cntryList = (List<ExchangeRateModel>) exchangeRateRepo.findAll();
	         
	        if(cntryList.size() > 0) {
	            return cntryList;
	        } else {
	            return new ArrayList<ExchangeRateModel>();
	        }
	    }
	 
	//get the values from the DB
		 public List<ExchangeRateModel> getExchangeRateDate(ExchangeRateListDTO exchangeRateListDTO)
		    {
			 
			 if (exchangeRateListDTO.getFromDate() != null && exchangeRateListDTO.getToDate() != null) {
				 List<ExchangeRateModel> cntryList = (List<ExchangeRateModel>)
			        		exchangeRateRepo.getExchangeRateDt(DateUtil.convertDateToString(exchangeRateListDTO.getFromDate()),DateUtil.convertDateToString(exchangeRateListDTO.getToDate()));
				 if(cntryList.size() > 0) {
			            return cntryList;
			        } else {
			            return new ArrayList<ExchangeRateModel>();
			        }    
			 }else {
				 List<ExchangeRateModel> cntryList = (List<ExchangeRateModel>)
			        		exchangeRateRepo.getExchangeRateDt(DateUtil.convertDateToString(exchangeRateListDTO.getFromDate()));
				 if(cntryList.size() > 0) {
			            return cntryList;
			        } else {
			            return new ArrayList<ExchangeRateModel>();
			        }   
			 }
		        
		        
		    }

}
