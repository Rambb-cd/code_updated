package com.exch.rate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exch.rate.model.ExchangeRateModel;

public interface ExchangeRateRepo extends JpaRepository<ExchangeRateModel, Long> , ExchangeRateCustomRepo{

}
