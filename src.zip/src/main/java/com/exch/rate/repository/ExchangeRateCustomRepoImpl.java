package com.exch.rate.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.exch.rate.model.ExchangeRateModel;

@Repository
@Transactional
public class ExchangeRateCustomRepoImpl implements ExchangeRateCustomRepo{
	
	 @PersistenceContext
	    EntityManager entityManager;
	    @Override
	    public List<ExchangeRateModel> getExchangeRateDt(String fromDate) {
	    //	 System.out.println("get Repo...::"+fromDate);
	        Query query = entityManager.createNativeQuery("SELECT * FROM EXCHANGE_RATES as cd " +
	                "WHERE cd.DATE_CON  = ?", ExchangeRateModel.class);
	        query.setParameter(1, fromDate);
	        return query.getResultList();
	    }
	    
	    @Override
	    public List<ExchangeRateModel> getExchangeRateDt(String fromDate,String toDate) {
	    	// System.out.println("get Repo111111...::"+fromDate);
	    	// System.out.println("get Repo11111...::"+toDate);
	        Query query = entityManager.createNativeQuery("SELECT * FROM EXCHANGE_RATES as cd " +
	                "WHERE cd.DATE_CON  BETWEEN  ? and  ?", ExchangeRateModel.class);
	        query.setParameter(1, fromDate);
	        query.setParameter(2, toDate);
	        return query.getResultList();
	    }

}
