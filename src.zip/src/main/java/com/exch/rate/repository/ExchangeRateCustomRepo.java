package com.exch.rate.repository;

import java.util.List;

import com.exch.rate.model.ExchangeRateModel;

public interface ExchangeRateCustomRepo {

	List<ExchangeRateModel> getExchangeRateDt(String date_con);
	List<ExchangeRateModel> getExchangeRateDt(String toDate,String fromDate);
}
