/**
 * 
 */
package com.exch.rate.dto;

import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter 
@Setter 
@NoArgsConstructor
public class ExchangeRateDTO extends BaseDTO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6390405607526029500L;
	private String baseCurrency;
	private Date exchangeRateDt;
	private String targetCurrency;
	private double exchangeRateAmt;
	
	
	public String getBaseCurrency() {
		return baseCurrency;
	}
	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}
	public Date getExchangeRateDt() {
		return exchangeRateDt;
	}
	public void setExchangeRateDt(Date exchangeRateDt) {
		this.exchangeRateDt = exchangeRateDt;
	}
	public String getTargetCurrency() {
		return targetCurrency;
	}
	public void setTargetCurrency(String targetCurrency) {
		this.targetCurrency = targetCurrency;
	}
	public double getExchangeRateAmt() {
		return exchangeRateAmt;
	}
	public void setExchangeRateAmt(double exchangeRateAmt) {
		this.exchangeRateAmt = exchangeRateAmt;
	}
	
}
