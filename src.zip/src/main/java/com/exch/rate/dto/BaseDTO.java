package com.exch.rate.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter 
@Setter 
@NoArgsConstructor
public class BaseDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5524157753076454117L;
	private String message;
}
