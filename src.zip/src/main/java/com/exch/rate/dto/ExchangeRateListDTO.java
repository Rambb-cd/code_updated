/**
 * 
 */
package com.exch.rate.dto;

import java.util.Date;
import java.util.ArrayList;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



public class ExchangeRateListDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5444180216658883692L;

	private Date fromDate;
	private Date toDate;
	private ArrayList<ExchangeRateDTO> exchangeRateList;
	
	
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public ArrayList<ExchangeRateDTO> getExchangeRateList() {
		return exchangeRateList;
	}
	public void setExchangeRateList(ArrayList<ExchangeRateDTO> exchangeRateList) {
		this.exchangeRateList = exchangeRateList;
	}
	
}
