package com.exch.rate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EXCHANGE_RATES")
public class ExchangeRateModel {
	

	@Id 
	@GeneratedValue
	private long id;
	
	
	
	@Column(name="base")
	private String baseCntry;
	
	
	@Column(name="target")
	private String targetCntry;
	
	@Column(name="value")
	private double valueCntry;
	
	@Column(name="date_con")
	private String date_conCntry;
	
	public String getBaseCntry() {
		return baseCntry;
	}
	public void setBaseCntry(String baseCntry) {
		this.baseCntry = baseCntry;
	}
	public String getTargetCntry() {
		return targetCntry;
	}
	public void setTargetCntry(String targetCntry) {
		this.targetCntry = targetCntry;
	}
	public double getValueCntry() {
		return valueCntry;
	}
	public void setValueCntry(double valueCntry) {
		this.valueCntry = valueCntry;
	}
	public String getDate_conCntry() {
		return date_conCntry;
	}
	public void setDate_conCntry(String date_conCntry) {
		this.date_conCntry = date_conCntry;
	}
	@Override
	public String toString() {
		return "ExchangeRateModel [id=" + id + ", baseCntry=" + baseCntry + ", targetCntry=" + targetCntry
				+ ", valueCntry=" + valueCntry + ", date_conCntry=" + date_conCntry + "]";
	}
	
	

}
