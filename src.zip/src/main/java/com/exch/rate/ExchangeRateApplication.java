package com.exch.rate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@EntityScan(basePackages="com.exch.rate.model")
@SpringBootApplication(scanBasePackages = { "com.exch.rate" })
public class ExchangeRateApplication {
	private static final Logger LOGGER = LogManager.getLogger(ExchangeRateApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(ExchangeRateApplication.class, args);	
		
		
	}
}