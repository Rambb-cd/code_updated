package com.exch.rate.controller;

import java.text.ParseException;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.exch.rate.ExchangeRateApplication;
import com.exch.rate.dto.ExchangeRateListDTO;
import com.exch.rate.model.ExchangeRateModel;
import com.exch.rate.service.ExchangeRateService;

@RestController
@RequestMapping("/ExchangeRate")
@CrossOrigin(maxAge=3600)
public class ExchangeRateLoadController {
	private static final Logger LOGGER = LogManager.getLogger(ExchangeRateLoadController.class);
	@Autowired
	private ExchangeRateService exchangeRateService;
	
	@GetMapping("/load")
	public String loadExchangeRates(@RequestParam(required=false) String fromDate,
			@RequestParam(required=false) String toDate) {
		LOGGER.info("ExchangeRateLoadController loadExchangeRates() starts");
		try {
			ExchangeRateListDTO exchangeRateListDTO = new ExchangeRateListDTO();
			if (fromDate != null) {
				exchangeRateListDTO.setFromDate(DateUtils.parseDate(fromDate, "yyyy-MM-dd"));
			}
			if (toDate != null) {
				exchangeRateListDTO.setToDate(DateUtils.parseDate(toDate, "yyyy-MM-dd"));
			}
			//System.out.println("From Date : " + exchangeRateListDTO.getFromDate());
			//System.out.println("To Date : " + exchangeRateListDTO.getToDate());
			exchangeRateService.loadExchangeRates(exchangeRateListDTO);
			if(null != exchangeRateListDTO.getExchangeRateList() 
					&& exchangeRateListDTO.getExchangeRateList().size()>0) {
			exchangeRateService.saveExchangeRates(exchangeRateListDTO);
			}
			
		} catch (ParseException prExp) {
			prExp.printStackTrace();
		}
		LOGGER.info("ExchangeRateLoadController loadExchangeRates() ends");
		return "Successfully loaded the data";
	}
	
	@GetMapping("/rate")
	public ResponseEntity<List<ExchangeRateModel>> getExchangeRates() {
		LOGGER.info("ExchangeRateLoadController getExchangeRates() starts");
		List<ExchangeRateModel> list = exchangeRateService.getExchangeRates();

		return new ResponseEntity<List<ExchangeRateModel>>(list, new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/rate_date")
	public ResponseEntity<List<ExchangeRateModel>> getExchangeRatesDate(
			@RequestParam(required=false) String fromDate,
			@RequestParam(required=false) String toDate) {
		LOGGER.info("ExchangeRateLoadController getExchangeRatesDate() starts");
		ExchangeRateListDTO exchangeRateListDTO = new ExchangeRateListDTO();
		try {			
			if (fromDate != null) {
				exchangeRateListDTO.setFromDate(DateUtils.parseDate(fromDate, "yyyy-MM-dd"));
			}
			if (toDate != null) {
				exchangeRateListDTO.setToDate(DateUtils.parseDate(toDate, "yyyy-MM-dd"));
			}			
			
		} catch (ParseException prExp) {
			prExp.printStackTrace();
		}
		List<ExchangeRateModel> list = exchangeRateService.getExchangeRateDate(exchangeRateListDTO);
		return new ResponseEntity<List<ExchangeRateModel>>(list, new HttpHeaders(), HttpStatus.OK);
	}
}